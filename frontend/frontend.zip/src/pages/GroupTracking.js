import React, { useEffect, useState } from "react";
import { Container, Typography, Button, TextField, List, ListItem, ListItemText } from "@mui/material";
import axios from "axios";

const GroupTracking = () => {
    const [groups, setGroups] = useState([]);
    const [groupName, setGroupName] = useState("");
    const [newUserId, setNewUserId] = useState("");
    const [selectedGroupId, setSelectedGroupId] = useState("");

    useEffect(() => {
        fetchGroups();
    }, []);

    const fetchGroups = async () => {
        try {
            const token = localStorage.getItem("token");
            const res = await axios.get("http://localhost:5000/groups/my-groups", {
                headers: { Authorization: `Bearer ${token}` },
            });
            setGroups(res.data);
        } catch (error) {
            console.error("Error fetching groups:", error);
        }
    };

    const createGroup = async () => {
        try {
            const token = localStorage.getItem("token");
            await axios.post(
                "http://localhost:5000/groups/create",
                { name: groupName },
                { headers: { Authorization: `Bearer ${token}` } }
            );
            setGroupName("");
            fetchGroups();
        } catch (error) {
            console.error("Error creating group:", error);
        }
    };

    const addUserToGroup = async () => {
        try {
            const token = localStorage.getItem("token");
            await axios.post(
                "http://localhost:5000/groups/add",
                { groupId: selectedGroupId, userId: newUserId },
                { headers: { Authorization: `Bearer ${token}` } }
            );
            setNewUserId("");
            fetchGroups();
        } catch (error) {
            console.error("Error adding user to group:", error);
        }
    };

    return (
        <Container maxWidth="md">
            <Typography variant="h4" align="center">Group Tracking</Typography>

            {/* Create Group */}
            <TextField label="Group Name" fullWidth margin="normal" value={groupName} 
                onChange={(e) => setGroupName(e.target.value)} />
            <Button variant="contained" color="primary" fullWidth onClick={createGroup}>
                Create Group
            </Button>

            {/* List of Groups */}
            <Typography variant="h6" style={{ marginTop: "20px" }}>Your Groups:</Typography>
            <List>
                {groups.map((group) => (
                    <ListItem key={group._id} button onClick={() => setSelectedGroupId(group._id)}>
                        <ListItemText primary={group.name} secondary={`Members: ${group.users.length}`} />
                    </ListItem>
                ))}
            </List>

            {/* Add User to Group */}
            {selectedGroupId && (
                <>
                    <TextField label="User ID to Add" fullWidth margin="normal" value={newUserId} 
                        onChange={(e) => setNewUserId(e.target.value)} />
                    <Button variant="contained" color="secondary" fullWidth onClick={addUserToGroup}>
                        Add User to Selected Group
                    </Button>
                </>
            )}
        </Container>
    );
};

export default GroupTracking;
