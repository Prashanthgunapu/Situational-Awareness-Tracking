import React, { useEffect, useState } from "react";
import Map, { Marker } from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import axios from "axios";

const LocationTracking = () => {
    const [viewport, setViewport] = useState({
        latitude: 37.7749, // Default to San Francisco
        longitude: -122.4194,
        zoom: 12
    });

    const [userLocation, setUserLocation] = useState(null);

    useEffect(() => {
        const fetchLocation = async () => {
            try {
                const token = localStorage.getItem("token");
                const res = await axios.get("http://localhost:5000/location", {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setUserLocation(res.data);
                setViewport({
                    latitude: res.data.latitude,
                    longitude: res.data.longitude,
                    zoom: 14
                });
            } catch (error) {
                console.error("Error fetching location:", error);
            }
        };

        fetchLocation();
        const interval = setInterval(fetchLocation, 5000); // Update location every 5 seconds
        return () => clearInterval(interval);
    }, []);

    return (
        <div style={{ width: "100%", height: "100vh" }}>
            <Map
                {...viewport}
                width="100%"
                height="100%"
                mapStyle="mapbox://styles/mapbox/streets-v11"
                mapboxAccessToken="pk.eyJ1IjoicHJhc2hhbnRoMDEzNSIsImEiOiJjbThna3RiOTQwcHI1MmlwdmdkOWJnOGQ2In0.cZYSpfIUeLmjWEw5GFyrUQ"
                onMove={(evt) => setViewport(evt.viewState)}
            >
                {userLocation && (
                    <Marker latitude={userLocation.latitude} longitude={userLocation.longitude}>
                        <div style={{ color: "red", fontSize: "20px" }}>📍</div>
                    </Marker>
                )}
            </Map>
        </div>
    );
};

export default LocationTracking;
