import React, { useEffect, useState } from "react";
import axios from "axios";
import { Container, Typography, Alert } from "@mui/material";

const Geofence = () => {
  const [alertMessage, setAlertMessage] = useState(null);

  useEffect(() => {
    const checkGeofence = async () => {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:5000/geofence/check", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.data.message.includes("outside")) {
        setAlertMessage(res.data.message);
      }
    };
    checkGeofence();
  }, []);

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" align="center">Geofencing Alerts</Typography>
      {alertMessage && <Alert severity="error">{alertMessage}</Alert>}
    </Container>
  );
};

export default Geofence;
